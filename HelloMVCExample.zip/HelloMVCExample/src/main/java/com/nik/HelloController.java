package com.nik;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	@RequestMapping("/index")
	public String setupForm(Map<String, Object> map) {

		return "success";
	}
	@RequestMapping("/login")
	public ModelAndView getLoginCheck(HttpServletRequest req, HttpServletResponse res)
	{
		String uname = req.getParameter("uname");
		String pwd = req.getParameter("pwd");
		ModelAndView mav = new ModelAndView();
		if (uname.equals("abc") && pwd.equals("xyz"))
		{
			mav.addObject("uname", uname);
			mav.setViewName("loginSuccess");
			System.out.println("login success!!");
		} 
		else 
		{
			mav.setViewName("loginFailed");

		}
		return mav;
	}
}
